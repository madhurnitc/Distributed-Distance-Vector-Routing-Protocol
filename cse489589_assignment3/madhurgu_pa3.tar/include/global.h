#ifndef GLOBAL_H_
#define GLOBAL_H_

#define HOSTNAME_LEN 128

#endif
